package com.fsp.disrup;

/**
 * Created by lucky on 2017/7/11.
 */
public class LongEvent {
    private long value;

    public void setValue(long value) {
        this.value = value;
    }
}
