package Hot;

/**
 * Created by lucky on 2017/7/24.
 */
public class HeroModule1 {
    public void test() {
        System.out.println("HeroModule1 tttttt");
    }

    public void test1() {
        System.out.println("HeroModule1 test");
    }
}
